sparkdl.udf module
===================

sparkdl.udf.keras\_image\_model module
--------------------------------------

.. automodule:: sparkdl.udf.keras_image_model
    :members:
    :undoc-members:
    :show-inheritance:
